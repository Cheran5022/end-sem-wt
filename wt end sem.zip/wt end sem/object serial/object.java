package file_manipulation;

import java.util.*;
import java.io.*;

public class serialization {
    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        System.out.println("Enter the name : ");
        String name = inp.nextLine();
        System.out.println("Enter the id : ");
        int id = inp.nextInt();
        Student fir = new Student(name,id);
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("stud.ser"))){
            oos.writeObject(fir);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("stud.ser"))){
            Student i = (Student) ois.readObject();
            System.out.println("Name : "+ i.getname());
            System.out.println(i.getid());
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}

class Student{
    private String name;
    private int id;
    public Student(String n,int i){
        this.name = n;
        this.id = i;
    }
    public String getname(){
        return name;
    }
    public int getid(){
        return id;
    }
}
