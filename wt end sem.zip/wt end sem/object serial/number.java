import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//import java.awt.event.ActionListener;

public class number extends JFrame implements ActionListener {
JFrame f;
JTextField tf;
JTextArea ta;
JButton b;
number() {
f=new JFrame("number to alphabets");
tf=new JTextField();
tf.setBounds(100,100,100,100);
b=new JButton("submit");
b.setBounds(350,150,100,100);
b.addActionListener(this);
ta= new JTextArea();
ta.setBounds(250,100,200,100);
f.add(b);
f.add(tf);
f.add(ta);
f.setSize(500,500);
f.setLayout(null);
f.setVisible(true);
//f.setLayout(null);
//b.addActionListener(this);
setDefaultCloseOperation(EXIT_ON_CLOSE);  
}
public void actionPerformed(ActionEvent e) {
String n=tf.getText();
int a=Integer.parseInt(n);
String result=" ";
if(a>1000) {
JOptionPane.showMessageDialog(this,"greater the 1000");
}
 if (a>99 && a<1000 ) {
  if(a/100==1) {
   result+="one";
   }
   else if(a/100==2) {
   result+="two";
   }
   else if(a/100==3) {
   result+="three";
   }
   else if(a/100==4) {
   result+="four";
   }
   else if(a/100==5) {
   result+="five";
   }
   else if(a/100==6) {
   result+="six";
   }
   else if(a/100==7) {
   result+="seven";
   }
   else if(a/100==8) {
   result+="eight";
   }
   else if(a/100==9) {
   result+="nine";
   }
   result+=" hundered ";
  } 
  
   int b=a/10;
   if(b%10==1) {
    result+="ten";
    }
   else if(b%10==2) {
   result+="twenty";
   }
   else if(b%10==3) {
   result+="thrity";
   }
   else if(b%10==4) {
   result+="fourty";
   }
   else if(b%10==5) {
   result+="fivty";
   }
   else if(b%10==6) {
   result+="sixty";
   }
   else if(b%10==7) {
   result+="seventy";
   }
   else if(b%10==8) {
   result+="eighty";
   }
   else if(b%10==9) {
   result+="ninety";
   }
   else {
   result+= "  ";
   }
   result+=" ";
   
   if(a%10==1) {
   result+="one";
   }
   else if(a%10==2) {
   result+="two";
   }
   else if(a%10==3) {
   result+="three";
   }
   else if(a%10==4) {
   result+="four";
   }
   else if(a%10==5) {
   result+="five";
   }
   else if(a%10==6) {
   result+="six";
   }
   else if(a%10==7) {
   result+="seven";
   }
   else if(a%10==8) {
   result+="eight";
   }
   else if(a%10==9) {
   result+="nine";
   }
   else {
   result+=" "; 
   }

ta.setText(result);
}
public static void main(String[] args) {
 new number();
 }
 }
