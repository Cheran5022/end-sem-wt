/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import static java.lang.System.out;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author charan
 */
@WebServlet(urlPatterns = {"/NewServlet"})
public class NewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          PrintWriter out= response.getWriter();
        String name=request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        out.print("name is "+name);
        String jdbcURL="jdbc:postgresql://localhost:5432/postgres";
        String dbname="postgres";
        String dbpassword="charan";
        
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NewServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        try (Connection connection=DriverManager.getConnection(jdbcURL,dbname,dbpassword)) {
           String query="insert into employee(name,age) values(?,?);";
           PreparedStatement preparedStatement=connection.prepareStatement(query);
           preparedStatement.setString(1,name);
           preparedStatement.setInt(2,age);
           int a=preparedStatement.executeUpdate();
           
           ResultSet resultSet=preparedStatement.executeQuery("select name,age from employee;");
           while(resultSet.next()) {
               String name1=resultSet.getString("name");
               int age1=resultSet.getInt("age");
               out.println("name is "+ name1 + "age is " + age1);
           }
           if(a>0) {
               response.getWriter().print("data is stored sucessfully");
            
           }
        } catch (SQLException e) {
           
        }        response.getWriter().print("data is not  stored sucessfully");
    }   
}