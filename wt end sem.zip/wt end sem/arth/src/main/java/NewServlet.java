/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author charan
 */

public class NewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            int first=Integer.parseInt(request.getParameter("first"));
            int second=Integer.parseInt(request.getParameter("second"));
            String operation=request.getParameter("operation");
            
            String jdbcURL="jdbc:postgresql://hostname:5432/postgres";
            String dbname="postgres";
            String dbpassword="charan";
            try {
            Class.forName("org.postgresql.Driven");
            } catch (ClassNotFoundException ex) {
            Logger.getLogger(NewServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            try (Connection connection= DriverManager.getConnection(jdbcURL,dbname,dbpassword)) {
             int result=0;
                if("add".equals(operation)) {
                 result=first+second;
             }
             else if("sub".equals(operation)) {
                  result=first-second;
             }
             else {
                response.getWriter().println("database is updateed");
             }
                 String query="insert into arth (first,second,operation,result) values(?,?,?,?)";
                 PreparedStatement preparedstatement=connection.prepareStatement(query);
                 preparedstatement.setInt(1,first);
                 preparedstatement.setInt(2,second);
                 preparedstatement.setString(3,operation);
                 preparedstatement.setInt(4,result);
                 int a=preparedstatement.executeUpdate();
                 if(a>0) {
                     response.getWriter().println("database is updateed");
                 }     
            } catch(SQLException e) {
                     response.getWriter().println("database is  updateed");
            }
       }
}


