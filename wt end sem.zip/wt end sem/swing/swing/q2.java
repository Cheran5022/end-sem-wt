import javax.swing.*;
import java.awt.event.*;


public class q2 extends JFrame implements  ActionListener {
JCheckBox c1,c2,c3;
JTextField t1,t2,t3;
JButton b;
q2() {
JFrame f= new JFrame("bill");
JLabel l1= new JLabel("ABC hostel");
l1.setBounds(50,50,100,100);
c1= new JCheckBox("chicken biriyani @ 200 ");
c2= new JCheckBox("chicken rice @ 100 ");
c3= new JCheckBox("parota @ 50 ");
c1.setBounds(100,100,100,100);
c2.setBounds(150,100,100,100);
c3.setBounds(200,100,100,100);

t1= new JTextField();
t2= new JTextField();
t3= new JTextField();
t1.setBounds(100,200,100,100);
t2.setBounds(100,200,100,100);
t3.setBounds(100,200,100,100);

b=new JButton("bill");
b.setBounds(300,150,100,100);
b.addActionListener(this);
f.add(b);
f.add(c1);
f.add(c2);
f.add(c3);
f.add(t1);
f.add(t2);
f.add(t3);
f.add(l1);
f.setSize(600,600);
f.setLayout(null);
f.setVisible(true);
//b.addActionListerner(this);
  setDefaultCloseOperation(EXIT_ON_CLOSE);  
}
public void ActionPerformed(ActionEvent e) {
int biriyani,rice,parota,total;
String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
int a=Integer.parseInt(s1);
int b1=Integer.parseInt(s2);
int c=Integer.parseInt(s3);
if(c1.isSelected()) {
   biriyani= 200*a;
   }
if(c2.isSelected()) {
   rice=100*b1;
   }
if(c3.isSelected()) {
   parota=50*c;
   }
   total=biriyani+rice + parota;
   JOptionPane.showMessageDialog(this,"bill amount is "+total);
   
 }
 public static void main(String[] args) {
 new q2();
 }
 }
   
   









