import javax.swing.*;
import java.awt.event.*;
public class q1 extends JFrame implements ActionListener {
 JTextField t1 ,t2;
 JFrame f;
 q1() {
  f= new JFrame("jbutton jlabel jtext field ");
 JLabel l1= new JLabel("enter the number:");
 l1.setBounds(50,20,250,250);
  t2= new JTextField();
  t1= new JTextField();
 t1.setBounds(50,150,100,100);
 t2.setBounds(100,150,100,100);
 JButton b1=new JButton("enter");
 b1.setBounds(50,250,100,100);
 // b1.addActionListener(this);
 f.setSize(500,500);
 f.add(l1);
 f.add(t1);
 f.add(b1);
 f.setLayout(null);
 f.setVisible(true);
 b1.addActionListener(this);
 }
 public void actionPerformed(ActionEvent e) {
 int area;
 String s1= t1.getText();
 int n=Integer.parseInt(s1);
 area= n*n;
 f.add(t2);
 String ar=Integer.toString(area);
 t2.setText(ar); 
 //JOptionPane.showMessageDialog(this ,"area is "+area);
  }
 
 
 public static void main(String[] args) {
  new q1();
 }
 }
 



