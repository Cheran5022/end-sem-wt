/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author charan
 */

public class NewServlet1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name =  request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        int phone = Integer.parseInt(request.getParameter("phone"));
        
        String jdbcURL="jdbc:postgresql://hostname :5432/postgres";
        String dbname="postgres";
        String dbpassword="charan";
        
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NewServlet1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try (Connection connection = DriverManager.getConnection(jdbcURL,dbname,dbpassword)) {
            String query="update employee set age= ? , phone= ? where name=?"; 
            PreparedStatement preparedstatement=connection.prepareStatement(query);
            preparedstatement.setInt(1,age);
             preparedstatement.setInt(2,phone);
              preparedstatement.setString(3,name);
            int rowupdate=preparedstatement.executeUpdate();
            if(rowupdate>0) {
                response.getWriter().println("updated the value");
                
            }
        } catch(SQLException e) {
            
        }
    }

}