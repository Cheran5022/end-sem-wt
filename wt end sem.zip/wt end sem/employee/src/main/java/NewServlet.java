import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/NewServlet")
public class NewServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        int phone = Integer.parseInt(request.getParameter("phone"));
        String operation=request.getParameter("operation");
        String jdbcURL;
        jdbcURL = "jdbc:postgresql://localhost:5432/postgres";
        String dbUser = "postgres";
        String dbPassword = "charan";
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NewServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            if("insert".equals(operation)) {
            String insertQuery = "INSERT INTO employee (name, age, phone) VALUES (?, ? ,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setInt(3, phone);
             int rowsInserted = preparedStatement.executeUpdate();
             if (rowsInserted > 0) {
                response.getWriter().println("Data has been stored in the database.");
            }
            }
            else if ("update".equals(operation)) {
            String insertQuery = "update employee set age=? ,phone= ? where name=?";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setInt(1,age);
            preparedStatement.setInt(2, phone);
            preparedStatement.setString(3, name);
             int rowsInserted = preparedStatement.executeUpdate();
             if (rowsInserted > 0) {
                response.getWriter().println("Data has been stored in the database.");
            }
            }
            else if ("delete".equals(operation)) {
            String insertQuery = "delete from employee where name=?";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            
            preparedStatement.setString(1,name);
             int rowsInserted = preparedStatement.executeUpdate();
             if (rowsInserted > 0) {
                response.getWriter().println("Data has been stored in the database.");
            }
            }
            else {
                 response.getWriter().println("operation does not match.");
                             
            }
            //int rowsInserted = preparedStatement.executeUpdate();
            //if (rowsInserted > 0) {
              //  response.getWriter().println("Data has been stored in the database.");
            //}
        } catch (SQLException e) {
        }
    }
}